package coms.SportyShoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportyShoes {

	public static void main(String[] args) {
		SpringApplication.run(SportyShoes.class, args);
		System.out.println("Server Started....");
	}

}
